import { useState, type FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { useLang } from '../i18n';
import { ApiError } from '../api';

const ROLES = ['buyer', 'renter', 'investor', 'seller', 'landlord', 'broker', 'lawyer', 'notary'] as const;
const ROLE_KEY: Record<(typeof ROLES)[number], string> = {
  buyer: 'role.buyer', renter: 'role.renter', investor: 'role.investor', seller: 'role.seller',
  landlord: 'role.landlord', broker: 'role.broker', lawyer: 'role.lawyer', notary: 'role.notary',
};

export default function Signup() {
  const { user, register } = useAuth();
  const { t, lang } = useLang();
  const navigate = useNavigate();
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', password: '', confirm: '', role: 'buyer', terms: false });
  const [fields, setFields] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError('');
    const fe: Record<string, string> = {};
    if (form.password !== form.confirm) fe.confirm = lang === 'es' ? 'Las contraseñas no coinciden.' : 'Passwords do not match.';
    if (!form.terms) fe.terms = lang === 'es' ? 'Debes aceptar los términos.' : 'You must accept the terms.';
    setFields(fe);
    if (Object.keys(fe).length > 0) return;
    setBusy(true);
    try {
      await register({
        firstName: form.firstName.trim(), lastName: form.lastName.trim(),
        email: form.email.trim(), password: form.password, role: form.role, locale: lang,
      });
      navigate('/signup/success', { replace: true });
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
        if (err.fields) setFields(err.fields);
      } else {
        setError(t('common.error'));
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="container">
      <div className="auth-card" style={{ maxWidth: 520 }}>
        <h1>{t('signup.title')}</h1>
        <form onSubmit={onSubmit} noValidate>
          <div className="form-row">
            <div className="field">
              <label htmlFor="first">{t('signup.first')}</label>
              <input id="first" autoComplete="given-name" required maxLength={60} value={form.firstName} onChange={(e) => set('firstName', e.target.value)} />
              {fields.firstName && <p className="err">{fields.firstName}</p>}
            </div>
            <div className="field">
              <label htmlFor="last">{t('signup.last')}</label>
              <input id="last" autoComplete="family-name" required maxLength={60} value={form.lastName} onChange={(e) => set('lastName', e.target.value)} />
              {fields.lastName && <p className="err">{fields.lastName}</p>}
            </div>
          </div>
          <div className="field">
            <label htmlFor="email">{t('login.email')}</label>
            <input id="email" type="email" autoComplete="email" required value={form.email} onChange={(e) => set('email', e.target.value)} />
            {fields.email && <p className="err">{fields.email}</p>}
          </div>
          <div className="field">
            <label htmlFor="role">{t('signup.role')}</label>
            <select id="role" value={form.role} onChange={(e) => set('role', e.target.value)}>
              {ROLES.map((r) => <option key={r} value={r}>{t(ROLE_KEY[r] as Parameters<typeof t>[0])}</option>)}
            </select>
          </div>
          <div className="form-row">
            <div className="field">
              <label htmlFor="password">{t('login.password')}</label>
              <input id="password" type="password" autoComplete="new-password" required minLength={10} value={form.password} onChange={(e) => set('password', e.target.value)} />
              {fields.password && <p className="err">{fields.password}</p>}
            </div>
            <div className="field">
              <label htmlFor="confirm">{t('signup.confirm')}</label>
              <input id="confirm" type="password" autoComplete="new-password" required value={form.confirm} onChange={(e) => set('confirm', e.target.value)} />
              {fields.confirm && <p className="err">{fields.confirm}</p>}
            </div>
          </div>
          <div className="field">
            <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', cursor: 'pointer' }}>
              <input type="checkbox" checked={form.terms} onChange={(e) => set('terms', e.target.checked)} style={{ marginTop: 3 }} />
              <span>{t('signup.terms')}</span>
            </label>
            {fields.terms && <p className="err">{fields.terms}</p>}
          </div>
          {error && <div className="alert error" role="alert">{error}</div>}
          <button className="btn gold" style={{ width: '100%' }} disabled={busy}>
            {busy ? t('common.loading') : t('signup.submit')}
          </button>
        </form>
        <p className="meta" style={{ marginTop: 18 }}>
          {t('signup.have')} <Link to="/login">{t('nav.login')}</Link>
        </p>
      </div>
    </main>
  );
}
