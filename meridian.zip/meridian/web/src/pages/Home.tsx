import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, type Property, type SearchResponse } from '../api';
import { useLang } from '../i18n';
import { useAuth, LISTING_ROLES } from '../auth';
import { HeroGlobe } from '../components/Logo';
import PropertyCard from '../components/PropertyCard';

export default function Home() {
  const { t } = useLang();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [listingType, setListingType] = useState('');
  const [featured, setFeatured] = useState<Property[]>([]);

  useEffect(() => {
    let cancelled = false;
    api.get<SearchResponse>('/api/properties?perPage=6&sort=newest')
      .then((d) => { if (!cancelled) setFeatured(d.results); })
      .catch(() => { /* hero still renders without listings */ });
    return () => { cancelled = true; };
  }, []);

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q.trim()) params.set('q', q.trim());
    if (listingType) params.set('listingType', listingType);
    navigate(`/search?${params.toString()}`);
  }

  const canList = user && LISTING_ROLES.includes(user.role);

  return (
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <p className="eyebrow">{t('hero.eyebrow')}</p>
            <h1>{t('hero.title')}</h1>
            <p className="lede">{t('hero.lede')}</p>
            <form className="searchbar" onSubmit={onSearch} role="search">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t('search.placeholder')}
                aria-label={t('search.placeholder')}
                maxLength={100}
              />
              <select value={listingType} onChange={(e) => setListingType(e.target.value)} aria-label={t('search.any')}>
                <option value="">{t('search.any')}</option>
                <option value="sale">{t('search.buy')}</option>
                <option value="rent">{t('search.rent')}</option>
              </select>
              <button className="btn gold" type="submit">{t('search.go')}</button>
            </form>
            <div className="hero-ctas">
              <Link className="btn outline" to="/search">{t('hero.cta.browse')}</Link>
              <Link className="btn ghost" to={canList ? '/dashboard/new' : '/signup'}>{t('hero.cta.list')}</Link>
            </div>
          </div>
          <div className="hero-globe" aria-hidden="true"><HeroGlobe /></div>
        </div>
      </section>

      <section className="section"><div className="container props3">
        {(['1', '2', '3'] as const).map((n) => (
          <div className="prop" key={n}>
            <h3>{t(`value.${n}.t` as Parameters<typeof t>[0])}</h3>
            <p>{t(`value.${n}.p` as Parameters<typeof t>[0])}</p>
          </div>
        ))}
      </div></section>

      {featured.length > 0 && (
        <section className="section"><div className="container">
          <div className="row-between">
            <h2>{t('featured.title')}</h2>
            <Link className="linkish" to="/search">{t('featured.viewAll')} →</Link>
          </div>
          <div className="cards">
            {featured.map((p) => <PropertyCard key={p.id} p={p} />)}
          </div>
        </div></section>
      )}

      <section className="section"><div className="container"><div className="cta-panel">
        <h2>{t('cta.title')}</h2>
        <p className="lede">{t('cta.lede')}</p>
        <Link className="btn gold" to={canList ? '/dashboard/new' : '/signup'}>{t('hero.cta.list')}</Link>
      </div></div></section>
    </main>
  );
}
