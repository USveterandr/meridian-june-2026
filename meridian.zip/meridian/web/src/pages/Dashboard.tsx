import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, formatPrice, type Property } from '../api';
import { useLang } from '../i18n';
import { useAuth, LISTING_ROLES } from '../auth';

type Mine = Property & { coverUrl?: string | null };

export default function Dashboard() {
  const { t, lang } = useLang();
  const { user } = useAuth();
  const [listings, setListings] = useState<Mine[] | null>(null);
  const [error, setError] = useState(false);
  const canList = user && LISTING_ROLES.includes(user.role);

  const load = useCallback(() => {
    api.get<{ results: Mine[] }>('/api/properties/mine')
      .then((d) => setListings(d.results))
      .catch(() => setError(true));
  }, []);

  useEffect(() => { if (canList) load(); else setListings([]); }, [canList, load]);

  async function setStatus(id: number, status: string) {
    try {
      await api.patch(`/api/properties/${id}`, { status });
      load();
    } catch { setError(true); }
  }

  async function remove(id: number) {
    const ok = window.confirm(lang === 'es' ? '¿Eliminar esta publicación de forma permanente?' : 'Permanently delete this listing?');
    if (!ok) return;
    try {
      await api.delete(`/api/properties/${id}`);
      load();
    } catch { setError(true); }
  }

  return (
    <main className="section">
      <div className="container">
        <div className="row-between">
          <h1>{t('dash.title')}</h1>
          <div className="hero-ctas" style={{ marginTop: 0 }}>
            <Link className="btn outline" to="/requirements">{t('dash.requirements')}</Link>
            {canList && <Link className="btn gold" to="/dashboard/new">+ {t('dash.newListing')}</Link>}
          </div>
        </div>

        {error && <div className="alert error">{t('common.error')}</div>}

        {canList && (
          <>
            <h2>{t('dash.myListings')}</h2>
            {listings === null && <p className="empty">{t('common.loading')}</p>}
            {listings !== null && listings.length === 0 && <p className="empty">{t('dash.noListings')}</p>}
            {listings !== null && listings.length > 0 && (
              <div style={{ overflowX: 'auto' }}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>{t('new.headline')}</th>
                      <th>{t('new.price')}</th>
                      <th>{t('dash.views.status')}</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {listings.map((p) => (
                      <tr key={p.id}>
                        <td><Link to={`/property/${p.id}`}>{p.title}</Link><div className="meta">{p.city}</div></td>
                        <td>{formatPrice(p.priceCents, p.currency, p.listingType, t('listing.perMonth'))}</td>
                        <td><span className="status-pill">{t(`status.${p.status}` as Parameters<typeof t>[0])}</span></td>
                        <td style={{ whiteSpace: 'nowrap' }}>
                          {p.status === 'draft' && (
                            <button className="btn small gold" onClick={() => setStatus(p.id, 'active')}>{t('status.publish')}</button>
                          )}{' '}
                          {p.status === 'active' && p.listingType === 'sale' && (
                            <button className="btn small ghost" onClick={() => setStatus(p.id, 'sold')}>{t('dash.markSold')}</button>
                          )}{' '}
                          {p.status === 'active' && p.listingType === 'rent' && (
                            <button className="btn small ghost" onClick={() => setStatus(p.id, 'rented')}>{t('dash.markRented')}</button>
                          )}{' '}
                          <button className="btn small danger" onClick={() => remove(p.id)}>{t('dash.delete')}</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {!canList && (
          <p className="lede">
            {lang === 'es'
              ? 'Guarda búsquedas, publica requerimientos y escribe a los propietarios — todo desde aquí.'
              : 'Save searches, post requirements, and message owners — all from here.'}
          </p>
        )}
      </div>
    </main>
  );
}
