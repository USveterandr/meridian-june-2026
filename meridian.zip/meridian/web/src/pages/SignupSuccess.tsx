import { Link } from 'react-router-dom';
import { useLang } from '../i18n';
import { useAuth, LISTING_ROLES } from '../auth';

export default function SignupSuccess() {
  const { t } = useLang();
  const { user } = useAuth();
  const canList = user && LISTING_ROLES.includes(user.role);
  return (
    <main className="container">
      <div className="auth-card" style={{ textAlign: 'center' }}>
        <h1>{t('signup.success.title')}</h1>
        <p className="lede">{t('signup.success.p')}</p>
        <div className="hero-ctas" style={{ justifyContent: 'center' }}>
          <Link className="btn gold" to="/dashboard">{t('nav.dashboard')}</Link>
          <Link className="btn outline" to={canList ? '/dashboard/new' : '/search'}>
            {canList ? t('dash.newListing') : t('nav.search')}
          </Link>
        </div>
      </div>
    </main>
  );
}
