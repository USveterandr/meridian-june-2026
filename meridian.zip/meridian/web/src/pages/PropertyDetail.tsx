import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, assetUrl, formatPrice, type Property } from '../api';
import { useLang } from '../i18n';
import { useAuth } from '../auth';

export default function PropertyDetail() {
  const { id } = useParams();
  const { t } = useLang();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [p, setP] = useState<Property | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [saved, setSaved] = useState(false);
  const [msg, setMsg] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setP(null);
    setNotFound(false);
    setSent(false);
    setSaved(false);
    if (!id || !/^\d+$/.test(id)) { setNotFound(true); return; }
    api.get<{ property: Property }>(`/api/properties/${id}`)
      .then((d) => { if (!cancelled) setP(d.property); })
      .catch(() => { if (!cancelled) setNotFound(true); });
    if (user) {
      api.get<{ results: { id: number }[] }>('/api/favorites')
        .then((d) => { if (!cancelled) setSaved(d.results.some((f) => f.id === Number(id))); })
        .catch(() => { /* favorites are optional UI sugar */ });
    }
    return () => { cancelled = true; };
  }, [id, user]);

  async function toggleSave() {
    if (!user) { navigate('/login'); return; }
    if (!p) return;
    try {
      if (saved) { await api.delete(`/api/favorites/${p.id}`); setSaved(false); }
      else { await api.post('/api/favorites', { propertyId: p.id }); setSaved(true); }
    } catch { /* leave state unchanged */ }
  }

  async function sendMessage(e: FormEvent) {
    e.preventDefault();
    if (!user) { navigate('/login'); return; }
    if (!p || !msg.trim() || sending) return;
    setSending(true);
    setError('');
    try {
      await api.post('/api/messages', { recipientId: p.ownerId, propertyId: p.id, body: msg.trim() });
      setSent(true);
      setMsg('');
    } catch (err) {
      setError(err instanceof Error ? err.message : t('common.error'));
    } finally {
      setSending(false);
    }
  }

  if (notFound) {
    return (
      <main className="section"><div className="container empty">
        <h1>{t('notfound.title')}</h1>
        <Link className="btn outline" to="/search">{t('nav.search')}</Link>
      </div></main>
    );
  }
  if (!p) return <main className="section"><div className="container empty">{t('common.loading')}</div></main>;

  const isOwner = user?.id === p.ownerId;
  const facts: Array<[string, string]> = [
    [t('detail.typeLabel'), t(`type.${p.propertyType}` as Parameters<typeof t>[0])],
    [t('detail.beds'), String(p.bedrooms)],
    [t('detail.baths'), String(p.bathrooms)],
  ];
  if (p.areaM2) facts.push([t('detail.area'), `${p.areaM2} m²`]);
  if (p.lotM2) facts.push([t('detail.lot'), `${p.lotM2} m²`]);
  if (p.yearBuilt) facts.push([t('detail.year'), String(p.yearBuilt)]);

  return (
    <main className="section">
      <div className="container">
        <p className="eyebrow">{p.city} · {p.listingType === 'sale' ? t('listing.forSale') : t('listing.forRent')}</p>
        <div className="row-between">
          <h1 style={{ marginBottom: 4 }}>{p.title}</h1>
          <span className="status-pill">{t(`status.${p.status}` as Parameters<typeof t>[0])}</span>
        </div>
        <p className="price" style={{ fontSize: '1.6rem' }}>
          {formatPrice(p.priceCents, p.currency, p.listingType, t('listing.perMonth'))}
        </p>

        {p.images.length > 0 && (
          <div className="gallery">
            {p.images.map((img) => {
              const src = assetUrl(img.url);
              return src ? <img key={img.id} src={src} alt={p.title} loading="lazy" /> : null;
            })}
          </div>
        )}

        <div className="detail-grid" style={{ marginTop: 28 }}>
          <div>
            <table className="table facts"><tbody>
              {facts.map(([k, v]) => <tr key={k}><th scope="row">{k}</th><td>{v}</td></tr>)}
            </tbody></table>

            {p.description && <p style={{ whiteSpace: 'pre-line', marginTop: 22 }}>{p.description}</p>}

            {p.features.length > 0 && (
              <>
                <h2 style={{ marginTop: 26 }}>{t('detail.features')}</h2>
                <div>{p.features.map((f) => <span className="feature-chip" key={f}>{f}</span>)}</div>
              </>
            )}

            {p.virtualTourUrl && (
              <p style={{ marginTop: 18 }}>
                <a className="btn outline" href={p.virtualTourUrl} target="_blank" rel="noopener noreferrer">
                  {t('detail.tour')} ↗
                </a>
              </p>
            )}
          </div>

          <aside className="aside-card">
            <p className="meta">{p.address}, {p.city}</p>
            <button className={`btn ${saved ? 'outline' : 'ghost'}`} style={{ width: '100%', marginBottom: 10 }} onClick={toggleSave}>
              {saved ? `✓ ${t('detail.saved')}` : `♡ ${t('detail.save')}`}
            </button>
            {!isOwner && (
              sent
                ? <div className="alert ok">✓</div>
                : (
                  <form onSubmit={sendMessage}>
                    <div className="field">
                      <label htmlFor="msg">{t('detail.contact')}</label>
                      <textarea id="msg" rows={4} maxLength={2000} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder={t('msg.placeholder')} required />
                    </div>
                    {error && <div className="alert error">{error}</div>}
                    <button className="btn gold" style={{ width: '100%' }} disabled={sending || !msg.trim()}>
                      {t('msg.send')}
                    </button>
                  </form>
                )
            )}
          </aside>
        </div>
      </div>
    </main>
  );
}
