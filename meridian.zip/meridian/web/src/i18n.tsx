import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

export type Lang = 'en' | 'es';

const STRINGS = {
  en: {
    'nav.search': 'Search', 'nav.favorites': 'Favorites', 'nav.messages': 'Messages',
    'nav.dashboard': 'Dashboard', 'nav.login': 'Sign in', 'nav.signup': 'Create account', 'nav.logout': 'Sign out',
    'hero.eyebrow': 'Dominican Republic · Caribbean',
    'hero.title': 'Where real wealth meets the Caribbean.',
    'hero.lede': 'Meridian connects buyers, investors, and owners across the Dominican Republic — verified listings, direct messaging, and the professionals to close with confidence.',
    'hero.cta.browse': 'Browse properties', 'hero.cta.list': 'List a property',
    'search.placeholder': 'City, keyword…', 'search.any': 'Buy or rent', 'search.buy': 'Buy', 'search.rent': 'Rent',
    'search.anyType': 'Any type', 'search.go': 'Search', 'search.results': 'results', 'search.none': 'No listings match these filters yet. Try widening the price range or removing a filter.',
    'search.minPrice': 'Min price (USD)', 'search.maxPrice': 'Max price (USD)', 'search.beds': 'Beds', 'search.sort': 'Sort',
    'sort.newest': 'Newest', 'sort.priceAsc': 'Price: low to high', 'sort.priceDesc': 'Price: high to low',
    'type.house': 'House', 'type.apartment': 'Apartment', 'type.condo': 'Condo', 'type.villa': 'Villa', 'type.land': 'Land', 'type.commercial': 'Commercial',
    'value.title': 'Why Meridian',
    'value.1.t': 'Built for the DR market', 'value.1.p': 'Prices in USD or DOP, listings in English and Spanish, and roles for the brokers, lawyers, and notaries every Dominican closing needs.',
    'value.2.t': 'Direct, private messaging', 'value.2.p': 'Talk to owners and professionals inside Meridian. No phone numbers exposed until you choose.',
    'value.3.t': 'Investor-grade detail', 'value.3.p': 'Square meters, lot size, year built, and features on every listing — the data you need to underwrite a deal.',
    'featured.title': 'Featured listings', 'featured.viewAll': 'View all',
    'cta.title': 'Own a property in the Dominican Republic?',
    'cta.lede': 'List it on Meridian and reach buyers and renters in two languages.',
    'login.title': 'Welcome back', 'login.email': 'Email', 'login.password': 'Password', 'login.submit': 'Sign in',
    'login.noAccount': 'New to Meridian?', 'login.create': 'Create an account',
    'signup.title': 'Create your account', 'signup.first': 'First name', 'signup.last': 'Last name',
    'signup.role': 'I am a…', 'signup.confirm': 'Confirm password', 'signup.terms': 'I agree to the Terms of Service and Privacy Policy.',
    'signup.submit': 'Create account', 'signup.have': 'Already have an account?',
    'signup.success.title': 'Welcome to Meridian', 'signup.success.p': 'Your account is ready. Save a search, favorite a property, or list your first one.',
    'role.buyer': 'Buyer', 'role.renter': 'Renter', 'role.investor': 'Investor', 'role.seller': 'Seller',
    'role.landlord': 'Landlord', 'role.broker': 'Real estate broker', 'role.lawyer': 'Lawyer', 'role.notary': 'Notary public',
    'dash.title': 'Dashboard', 'dash.myListings': 'My listings', 'dash.newListing': 'Add new listing',
    'dash.requirements': 'My requirements', 'dash.noListings': 'You have no listings yet.',
    'dash.views.status': 'Status', 'dash.markSold': 'Mark sold', 'dash.markRented': 'Mark rented', 'dash.delete': 'Delete',
    'fav.title': 'Favorites', 'fav.none': 'Nothing saved yet. Tap “Save” on any listing to keep it here.',
    'msg.title': 'Messages', 'msg.none': 'No conversations yet. Contact an owner from any listing to start one.',
    'msg.send': 'Send', 'msg.placeholder': 'Write a message…',
    'detail.contact': 'Message the owner', 'detail.save': 'Save to favorites', 'detail.saved': 'Saved',
    'detail.beds': 'Bedrooms', 'detail.baths': 'Bathrooms', 'detail.area': 'Area', 'detail.lot': 'Lot',
    'detail.year': 'Year built', 'detail.typeLabel': 'Type', 'detail.features': 'Features & amenities',
    'detail.tour': 'Open virtual tour',
    'listing.forSale': 'For sale', 'listing.forRent': 'For rent', 'listing.perMonth': '/mo',
    'common.loading': 'Loading…', 'common.error': 'Something went wrong. Please try again.',
    'common.cancel': 'Cancel', 'common.save': 'Save', 'common.back': 'Back', 'common.next': 'Next',
    'footer.tag': 'Premium real estate & investment — Dominican Republic, then the world.',
    'new.title': 'Add new listing', 'new.step1': 'Basics', 'new.step2': 'Details', 'new.step3': 'Features', 'new.step4': 'Photos',
    'new.listingType': 'Listing type', 'new.propertyType': 'Property type', 'new.price': 'Price (USD)',
    'new.priceRentHint': 'Monthly rent in USD', 'new.headline': 'Headline / title', 'new.address': 'Address',
    'new.city': 'City', 'new.description': 'Description', 'new.sqm': 'Area (m²)', 'new.lot': 'Lot size (m²)',
    'new.beds': 'Bedrooms', 'new.baths': 'Bathrooms', 'new.year': 'Year built', 'new.parking': 'Parking spaces',
    'new.featuresHint': 'Select all that apply', 'new.extraFeatures': 'Other features (comma separated)',
    'new.tourUrl': 'Virtual tour URL (optional)', 'new.publish': 'Publish listing', 'new.draft': 'Save as draft',
    'new.photos': 'Photos', 'new.photosHint': 'JPEG, PNG or WebP, up to 8 MB each.', 'new.upload': 'Upload photos',
    'new.created': 'Listing created. Add photos below, or view it live.', 'new.view': 'View listing',
    'feat.ac': 'Air conditioning', 'feat.pool': 'Pool', 'feat.balcony': 'Balcony', 'feat.garden': 'Garden',
    'feat.oceanview': 'Ocean view', 'feat.furnished': 'Furnished', 'feat.gated': 'Gated community',
    'feat.washer': 'Washer/Dryer', 'feat.dishwasher': 'Dishwasher', 'feat.heating': 'Heating', 'feat.fireplace': 'Fireplace',
    'req.title': 'Post a requirement', 'req.lede': 'Tell us what you need — we match it against new listings.',
    'req.budget': 'Max budget (USD)', 'req.minBeds': 'Min bedrooms', 'req.notes': 'Specific needs (keywords)',
    'req.submit': 'Post requirement', 'req.none': 'No requirements yet.', 'req.matches': 'matches',
    'req.viewMatches': 'View matches', 'req.delete': 'Delete',
    'status.draft': 'Draft', 'status.active': 'Active', 'status.pending': 'Pending', 'status.sold': 'Sold',
    'status.rented': 'Rented', 'status.inactive': 'Inactive', 'status.publish': 'Publish',
    'notfound.title': 'Page not found', 'notfound.p': 'The page you’re looking for doesn’t exist.', 'notfound.home': 'Go home',
  },
  es: {
    'nav.search': 'Buscar', 'nav.favorites': 'Favoritos', 'nav.messages': 'Mensajes',
    'nav.dashboard': 'Panel', 'nav.login': 'Iniciar sesión', 'nav.signup': 'Crear cuenta', 'nav.logout': 'Cerrar sesión',
    'hero.eyebrow': 'República Dominicana · Caribe',
    'hero.title': 'Donde la riqueza real encuentra el Caribe.',
    'hero.lede': 'Meridian conecta compradores, inversionistas y propietarios en la República Dominicana — listados verificados, mensajería directa y los profesionales para cerrar con confianza.',
    'hero.cta.browse': 'Ver propiedades', 'hero.cta.list': 'Publicar propiedad',
    'search.placeholder': 'Ciudad, palabra clave…', 'search.any': 'Comprar o alquilar', 'search.buy': 'Comprar', 'search.rent': 'Alquilar',
    'search.anyType': 'Cualquier tipo', 'search.go': 'Buscar', 'search.results': 'resultados', 'search.none': 'Ningún listado coincide con estos filtros. Amplía el rango de precio o quita un filtro.',
    'search.minPrice': 'Precio mín. (USD)', 'search.maxPrice': 'Precio máx. (USD)', 'search.beds': 'Habit.', 'search.sort': 'Ordenar',
    'sort.newest': 'Más recientes', 'sort.priceAsc': 'Precio: menor a mayor', 'sort.priceDesc': 'Precio: mayor a menor',
    'type.house': 'Casa', 'type.apartment': 'Apartamento', 'type.condo': 'Condominio', 'type.villa': 'Villa', 'type.land': 'Terreno', 'type.commercial': 'Comercial',
    'value.title': 'Por qué Meridian',
    'value.1.t': 'Hecho para el mercado dominicano', 'value.1.p': 'Precios en USD o DOP, listados en inglés y español, y roles para corredores, abogados y notarios que todo cierre dominicano necesita.',
    'value.2.t': 'Mensajería directa y privada', 'value.2.p': 'Habla con propietarios y profesionales dentro de Meridian. Tu número no se expone hasta que tú decidas.',
    'value.3.t': 'Detalle para inversionistas', 'value.3.p': 'Metros cuadrados, solar, año de construcción y amenidades en cada listado — los datos para evaluar una inversión.',
    'featured.title': 'Listados destacados', 'featured.viewAll': 'Ver todos',
    'cta.title': '¿Tienes una propiedad en la República Dominicana?',
    'cta.lede': 'Publícala en Meridian y llega a compradores e inquilinos en dos idiomas.',
    'login.title': 'Bienvenido de nuevo', 'login.email': 'Correo', 'login.password': 'Contraseña', 'login.submit': 'Iniciar sesión',
    'login.noAccount': '¿Nuevo en Meridian?', 'login.create': 'Crear una cuenta',
    'signup.title': 'Crea tu cuenta', 'signup.first': 'Nombre', 'signup.last': 'Apellido',
    'signup.role': 'Soy…', 'signup.confirm': 'Confirmar contraseña', 'signup.terms': 'Acepto los Términos de Servicio y la Política de Privacidad.',
    'signup.submit': 'Crear cuenta', 'signup.have': '¿Ya tienes una cuenta?',
    'signup.success.title': 'Bienvenido a Meridian', 'signup.success.p': 'Tu cuenta está lista. Guarda una búsqueda, marca una propiedad favorita o publica la primera tuya.',
    'role.buyer': 'Comprador', 'role.renter': 'Inquilino', 'role.investor': 'Inversionista', 'role.seller': 'Vendedor',
    'role.landlord': 'Propietario', 'role.broker': 'Corredor inmobiliario', 'role.lawyer': 'Abogado', 'role.notary': 'Notario público',
    'dash.title': 'Panel', 'dash.myListings': 'Mis listados', 'dash.newListing': 'Agregar listado',
    'dash.requirements': 'Mis requisitos', 'dash.noListings': 'Aún no tienes listados.',
    'dash.views.status': 'Estado', 'dash.markSold': 'Marcar vendido', 'dash.markRented': 'Marcar alquilado', 'dash.delete': 'Eliminar',
    'fav.title': 'Favoritos', 'fav.none': 'Nada guardado aún. Toca “Guardar” en cualquier listado para tenerlo aquí.',
    'msg.title': 'Mensajes', 'msg.none': 'Sin conversaciones aún. Contacta a un propietario desde cualquier listado para empezar.',
    'msg.send': 'Enviar', 'msg.placeholder': 'Escribe un mensaje…',
    'detail.contact': 'Mensaje al propietario', 'detail.save': 'Guardar en favoritos', 'detail.saved': 'Guardado',
    'detail.beds': 'Habitaciones', 'detail.baths': 'Baños', 'detail.area': 'Área', 'detail.lot': 'Solar',
    'detail.year': 'Año de construcción', 'detail.typeLabel': 'Tipo', 'detail.features': 'Amenidades',
    'detail.tour': 'Abrir tour virtual',
    'listing.forSale': 'En venta', 'listing.forRent': 'En alquiler', 'listing.perMonth': '/mes',
    'common.loading': 'Cargando…', 'common.error': 'Algo salió mal. Inténtalo de nuevo.',
    'common.cancel': 'Cancelar', 'common.save': 'Guardar', 'common.back': 'Atrás', 'common.next': 'Siguiente',
    'footer.tag': 'Bienes raíces e inversión premium — República Dominicana, luego el mundo.',
    'new.title': 'Publicar propiedad', 'new.step1': 'Básicos', 'new.step2': 'Detalles', 'new.step3': 'Características', 'new.step4': 'Fotos',
    'new.listingType': 'Tipo de publicación', 'new.propertyType': 'Tipo de propiedad', 'new.price': 'Precio (USD)',
    'new.priceRentHint': 'Renta mensual en USD', 'new.headline': 'Título', 'new.address': 'Dirección',
    'new.city': 'Ciudad', 'new.description': 'Descripción', 'new.sqm': 'Área (m²)', 'new.lot': 'Terreno (m²)',
    'new.beds': 'Habitaciones', 'new.baths': 'Baños', 'new.year': 'Año de construcción', 'new.parking': 'Parqueos',
    'new.featuresHint': 'Selecciona las que apliquen', 'new.extraFeatures': 'Otras características (separadas por coma)',
    'new.tourUrl': 'URL de tour virtual (opcional)', 'new.publish': 'Publicar', 'new.draft': 'Guardar borrador',
    'new.photos': 'Fotos', 'new.photosHint': 'JPEG, PNG o WebP, hasta 8 MB cada una.', 'new.upload': 'Subir fotos',
    'new.created': 'Propiedad creada. Agrega fotos abajo o mírala en vivo.', 'new.view': 'Ver publicación',
    'feat.ac': 'Aire acondicionado', 'feat.pool': 'Piscina', 'feat.balcony': 'Balcón', 'feat.garden': 'Jardín',
    'feat.oceanview': 'Vista al mar', 'feat.furnished': 'Amueblado', 'feat.gated': 'Residencial cerrado',
    'feat.washer': 'Lavadora/Secadora', 'feat.dishwasher': 'Lavavajillas', 'feat.heating': 'Calefacción', 'feat.fireplace': 'Chimenea',
    'req.title': 'Publicar un requerimiento', 'req.lede': 'Dinos qué buscas — lo comparamos con nuevas publicaciones.',
    'req.budget': 'Presupuesto máx. (USD)', 'req.minBeds': 'Habitaciones mín.', 'req.notes': 'Necesidades específicas (palabras clave)',
    'req.submit': 'Publicar requerimiento', 'req.none': 'Aún no hay requerimientos.', 'req.matches': 'coincidencias',
    'req.viewMatches': 'Ver coincidencias', 'req.delete': 'Eliminar',
    'status.draft': 'Borrador', 'status.active': 'Activa', 'status.pending': 'Pendiente', 'status.sold': 'Vendida',
    'status.rented': 'Alquilada', 'status.inactive': 'Inactiva', 'status.publish': 'Publicar',
    'notfound.title': 'Página no encontrada', 'notfound.p': 'La página que buscas no existe.', 'notfound.home': 'Ir al inicio',
  },
} as const;

type Key = keyof (typeof STRINGS)['en'];

type Ctx = { lang: Lang; t: (k: Key) => string; setLang: (l: Lang) => void };
const LanguageContext = createContext<Ctx | null>(null);

function detectLang(): Lang {
  try {
    const saved = localStorage.getItem('meridian_lang');
    if (saved === 'en' || saved === 'es') return saved;
    return (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en';
  } catch {
    return 'en';
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(detectLang);
  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try { localStorage.setItem('meridian_lang', l); } catch { /* private mode */ }
    document.documentElement.lang = l;
  }, []);
  const t = useCallback((k: Key) => STRINGS[lang][k] ?? STRINGS.en[k] ?? k, [lang]);
  const value = useMemo(() => ({ lang, t, setLang }), [lang, t, setLang]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLang(): Ctx {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLang must be used inside LanguageProvider');
  return ctx;
}

export function LanguageToggle() {
  const { lang, setLang } = useLang();
  const next = lang === 'en' ? 'es' : 'en';
  return (
    <button
      className="linkish"
      onClick={() => setLang(next)}
      aria-label={next === 'es' ? 'Cambiar a español' : 'Switch to English'}
    >
      {lang === 'en' ? 'ES' : 'EN'}
    </button>
  );
}
