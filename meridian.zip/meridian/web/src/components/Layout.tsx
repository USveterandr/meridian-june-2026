import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LanguageToggle, useLang } from '../i18n';
import { useAuth } from '../auth';
import { api } from '../api';
import { GlobeMark } from './Logo';

function ThemeToggle() {
  const [theme, setTheme] = useState<string>(() => {
    try { return localStorage.getItem('meridian_theme') ?? 'dark'; } catch { return 'dark'; }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('meridian_theme', theme); } catch { /* ignore */ }
  }, [theme]);
  return (
    <button
      className="linkish"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
    >
      {theme === 'dark' ? '☀' : '☾'}
    </button>
  );
}

export default function Layout() {
  const { t } = useLang();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) { setUnread(0); return; }
    let cancelled = false;
    const load = () => {
      api.get<{ unread: number }>('/api/messages/unread-count')
        .then((d) => { if (!cancelled) setUnread(d.unread); })
        .catch(() => { /* non-critical */ });
    };
    load();
    const id = window.setInterval(load, 60_000);
    return () => { cancelled = true; window.clearInterval(id); };
  }, [user]);

  return (
    <>
      <a href="#main" className="visually-hidden" style={{ position: 'absolute', left: -9999 }}>Skip to content</a>
      <header className="site-header">
        <div className="header-inner">
          <Link to="/" className="brand" aria-label="Meridian home">
            <GlobeMark />
            <span className="brand-name">MERIDIAN</span>
          </Link>
          <nav className="nav" aria-label="Main">
            <NavLink to="/search">{t('nav.search')}</NavLink>
            {user && <NavLink to="/favorites">{t('nav.favorites')}</NavLink>}
            {user && (
              <NavLink to="/messages">
                {t('nav.messages')}
                {unread > 0 && <span className="badge">{unread}</span>}
              </NavLink>
            )}
            {user && <NavLink to="/dashboard">{t('nav.dashboard')}</NavLink>}
            {!user && <NavLink to="/login">{t('nav.login')}</NavLink>}
            {!user && <NavLink to="/signup" className="gold">{t('nav.signup')}</NavLink>}
            {user && (
              <button className="linkish" onClick={() => { logout(); navigate('/'); }}>
                {t('nav.logout')}
              </button>
            )}
            <LanguageToggle />
            <ThemeToggle />
          </nav>
        </div>
      </header>
      <main id="main">
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="container footer-grid">
          <div>
            <div className="brand" style={{ marginBottom: 8 }}>
              <GlobeMark size={26} />
              <span className="brand-name" style={{ fontSize: '1.1rem' }}>MERIDIAN</span>
            </div>
            <p style={{ maxWidth: '38ch', margin: 0 }}>{t('footer.tag')}</p>
          </div>
          <div>
            <p style={{ margin: 0 }}>© {new Date().getFullYear()} Meridian. Santo Domingo, República Dominicana.</p>
          </div>
        </div>
      </footer>
    </>
  );
}
