import { Link } from 'react-router-dom';
import { assetUrl, formatPrice, type Property } from '../api';
import { useLang } from '../i18n';

export default function PropertyCard({ p }: { p: Pick<Property,
  'id' | 'title' | 'city' | 'priceCents' | 'currency' | 'listingType' | 'propertyType' | 'bedrooms' | 'bathrooms'> & { coverUrl?: string | null } }) {
  const { t } = useLang();
  const cover = assetUrl(p.coverUrl ?? null);
  return (
    <article className="card">
      <div className="thumb">
        {cover
          ? <img src={cover} alt={p.title} loading="lazy" />
          : <div className="noimg" aria-hidden="true">Meridian</div>}
        <span className="tag">{p.listingType === 'sale' ? t('listing.forSale') : t('listing.forRent')}</span>
      </div>
      <div className="body">
        <div className="price">{formatPrice(p.priceCents, p.currency, p.listingType, t('listing.perMonth'))}</div>
        <div style={{ marginTop: 2 }}>{p.title}</div>
        <div className="meta">
          {p.city} · {p.bedrooms} {t('detail.beds').toLowerCase()} · {p.bathrooms} {t('detail.baths').toLowerCase()}
        </div>
      </div>
      <Link to={`/property/${p.id}`} className="cover" aria-label={p.title} />
    </article>
  );
}
