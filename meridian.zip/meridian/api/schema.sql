-- Meridian D1 schema. Idempotent: safe to run more than once.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  first_name    TEXT NOT NULL,
  last_name     TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'buyer'
                CHECK (role IN ('buyer','renter','investor','seller','landlord','broker','lawyer','notary','admin')),
  phone         TEXT,
  locale        TEXT NOT NULL DEFAULT 'en' CHECK (locale IN ('en','es')),
  notify_matches  INTEGER NOT NULL DEFAULT 1,
  notify_messages INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS properties (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  description   TEXT NOT NULL DEFAULT '',
  property_type TEXT NOT NULL CHECK (property_type IN ('house','apartment','condo','villa','land','commercial')),
  listing_type  TEXT NOT NULL CHECK (listing_type IN ('sale','rent')),
  -- Money is stored as integer cents to avoid floating point rounding bugs.
  price_cents   INTEGER NOT NULL CHECK (price_cents > 0),
  currency      TEXT NOT NULL DEFAULT 'USD' CHECK (currency IN ('USD','DOP')),
  address       TEXT NOT NULL,
  city          TEXT NOT NULL,
  country       TEXT NOT NULL DEFAULT 'DO' CHECK (length(country) = 2),
  latitude      REAL,
  longitude     REAL,
  bedrooms      INTEGER NOT NULL DEFAULT 0 CHECK (bedrooms BETWEEN 0 AND 50),
  bathrooms     REAL    NOT NULL DEFAULT 0 CHECK (bathrooms BETWEEN 0 AND 50),
  area_m2       REAL CHECK (area_m2 IS NULL OR area_m2 > 0),
  lot_m2        REAL CHECK (lot_m2 IS NULL OR lot_m2 > 0),
  year_built    INTEGER CHECK (year_built IS NULL OR year_built BETWEEN 1800 AND 2100),
  features      TEXT NOT NULL DEFAULT '[]', -- JSON array of feature strings
  virtual_tour_url TEXT,
  status        TEXT NOT NULL DEFAULT 'active'
                CHECK (status IN ('draft','active','pending','sold','rented','inactive')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_properties_search
  ON properties (status, listing_type, property_type, city, price_cents);
CREATE INDEX IF NOT EXISTS idx_properties_owner ON properties (owner_id);
CREATE INDEX IF NOT EXISTS idx_properties_created ON properties (created_at DESC);

CREATE TABLE IF NOT EXISTS property_images (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  r2_key      TEXT NOT NULL UNIQUE,
  content_type TEXT NOT NULL,
  position    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_images_property ON property_images (property_id, position);

CREATE TABLE IF NOT EXISTS requirements (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  listing_type  TEXT NOT NULL CHECK (listing_type IN ('sale','rent')),
  property_type TEXT CHECK (property_type IS NULL OR property_type IN ('house','apartment','condo','villa','land','commercial')),
  city          TEXT,
  max_price_cents INTEGER CHECK (max_price_cents IS NULL OR max_price_cents > 0),
  min_bedrooms  INTEGER NOT NULL DEFAULT 0,
  min_bathrooms REAL NOT NULL DEFAULT 0,
  notes       TEXT NOT NULL DEFAULT '',
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_requirements_user ON requirements (user_id);

CREATE TABLE IF NOT EXISTS messages (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  property_id  INTEGER REFERENCES properties(id) ON DELETE SET NULL,
  body         TEXT NOT NULL,
  read_at      TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages (recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages (sender_id, created_at DESC);

CREATE TABLE IF NOT EXISTS favorites (
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, property_id)
);
