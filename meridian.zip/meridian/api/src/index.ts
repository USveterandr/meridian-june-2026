import { Hono } from 'hono';
import { cors } from 'hono/cors';
import auth from './routes/auth';
import properties from './routes/properties';
import favorites from './routes/favorites';
import requirements from './routes/requirements';
import messages from './routes/messages';
import assets from './routes/assets';
import type { AppEnv } from './types';

const app = new Hono<AppEnv>();

// Fail fast and loud if the deployment is missing its secret, instead of
// silently signing tokens with `undefined`.
app.use('*', async (c, next) => {
  if (!c.env.JWT_SECRET || c.env.JWT_SECRET.length < 32) {
    console.error('JWT_SECRET is missing or too short. Run: npx wrangler secret put JWT_SECRET');
    return c.json({ error: 'Server configuration error.' }, 500);
  }
  await next();
});

// Security headers on every response.
app.use('*', async (c, next) => {
  await next();
  c.res.headers.set('X-Content-Type-Options', 'nosniff');
  c.res.headers.set('X-Frame-Options', 'DENY');
  c.res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  c.res.headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  c.res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
});

// CORS allowlist from env — never a wildcard.
app.use('/api/*', async (c, next) => {
  const allowed = (c.env.ALLOWED_ORIGINS ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  const handler = cors({
    origin: (origin) => (allowed.includes(origin) ? origin : null),
    allowMethods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization'],
    maxAge: 86400,
  });
  return handler(c, next);
});

app.get('/api/health', (c) => c.json({ ok: true, service: 'meridian-api' }));

app.route('/api/auth', auth);
app.route('/api/properties', properties);
app.route('/api/favorites', favorites);
app.route('/api/requirements', requirements);
app.route('/api/messages', messages);
app.route('/api/assets', assets);

app.notFound((c) => c.json({ error: 'Not found.' }, 404));

// Central error handler: log details server-side, never leak stack traces
// or SQL fragments to the client.
app.onError((err, c) => {
  console.error('Unhandled error:', err instanceof Error ? err.stack : err);
  return c.json({ error: 'Something went wrong on our side. Please try again.' }, 500);
});

export default app;
